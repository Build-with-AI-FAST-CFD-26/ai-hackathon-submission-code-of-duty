import { useState, useEffect } from 'react';
import { Sidebar, Navbar } from './components/layout/Shell';
import { Dashboard } from './components/dashboard/Dashboard';
import { LeadsPage } from './components/leads/LeadsPage';
import { AnalyticsPage } from './components/analytics/AnalyticsPage';
import { StackSenseAssistant } from './components/assistant/StackSenseAssistant';
import { AuthOverlay } from './components/auth/AuthOverlay';
import { auth } from './lib/firebase';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { I18nextProvider } from 'react-i18next';
import i18n from './lib/i18n';
import './index.css';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  
  useEffect(() => {
    console.log("FounderStack: App mounted, initializing auth...");
    
    // Safety timeout for auth loading
    const timeout = setTimeout(() => {
      if (authLoading) {
        console.warn("FounderStack: Auth initialization timed out after 10s");
        setAuthLoading(false);
        setAuthError("Auth initialization timed out. Please refresh or check your connection.");
      }
    }, 10000);

    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      console.log("FounderStack: Auth state changed. User:", currentUser?.email || "Logged out");
      setUser(currentUser);
      setAuthLoading(false);
      clearTimeout(timeout);
    }, (error) => {
      console.error("FounderStack: Auth observer error:", error);
      setAuthError(error.message);
      setAuthLoading(false);
      clearTimeout(timeout);
    });

    return () => {
      unsubscribe();
      clearTimeout(timeout);
    };
  }, []);

  const handleSignOut = async () => {
    console.log("FounderStack: Signing out...");
    try {
      await signOut(auth);
    } catch (err) {
      console.error("Sign out error:", err);
    }
  };

  if (authLoading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-slate-200 border-t-blue-600 rounded-full animate-spin" />
          <p className="text-slate-500 font-medium animate-pulse">Syncing FounderStack...</p>
          <p className="text-[10px] text-slate-400">Verifying session with Firebase</p>
        </div>
      </div>
    );
  }

  if (authError && !user) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-50 p-6 text-center">
        <div className="max-w-md">
          <p className="text-red-500 font-bold mb-2">Initialization Error</p>
          <p className="text-slate-600 mb-6">{authError}</p>
          <button 
            onClick={() => window.location.reload()}
            className="px-6 py-2 bg-slate-900 text-white rounded-xl font-bold"
          >
            Refresh Page
          </button>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthOverlay />;
  }

  return (
    <I18nextProvider i18n={i18n}>
      <div className="flex min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-blue-100 selection:text-blue-900">
        <Sidebar activeTab={activeTab} onTabChange={setActiveTab} onSignOut={handleSignOut} />
        <main className="flex-1 flex flex-col min-w-0">
          <Navbar />
          <div className="p-8 pb-24 overflow-y-auto max-w-7xl mx-auto w-full">
            {activeTab === 'dashboard' && <Dashboard onTabChange={setActiveTab} />}
            {activeTab === 'leads' && <LeadsPage />}
            {activeTab === 'analytics' && <AnalyticsPage />}
            {activeTab === 'settings' && (
              <div className="text-center py-20 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="max-w-md mx-auto p-8 bg-white border border-slate-200 rounded-3xl shadow-sm text-left">
                  <h2 className="text-2xl font-bold text-slate-900 mb-6">Settings</h2>
                  <div className="space-y-4">
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-slate-400 uppercase">Authenticated User</span>
                      <span className="font-medium text-slate-900">{user.email}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-slate-400 uppercase">Role</span>
                      <span className="font-medium text-blue-600">Founder (Owner)</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
        <StackSenseAssistant />
      </div>
    </I18nextProvider>
  );
}

export default App;
