import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

console.log('FounderStack: main.tsx loaded');

const container = document.getElementById('root');
if (container) {
  console.log('FounderStack: root element found, rendering...');
  const root = createRoot(container);
  root.render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
} else {
  console.error('FounderStack: root element not found!');
}
