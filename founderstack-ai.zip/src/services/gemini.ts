import { GoogleGenAI } from "@google/genai";

let aiInstance: GoogleGenAI | null = null;

export function getGemini() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing. Check your Secrets panel.");
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

export type AssistantCategory = "Lead" | "AI" | "Decision" | "Meeting";

export interface AssistantResponse {
  category: AssistantCategory;
  summary: string;
  actionNeeded?: string;
  costImpact?: string;
  details: string;
}

export async function askAssistant(prompt: string): Promise<AssistantResponse> {
  const ai = getGemini();
  const SYSTEM_PROMPT = `
    You are "FounderStack AI" — a virtual assistant for startup founders.
    
    RULES:
    1. LEAD TRACKING: If user mentions "lead" or "customer", ask for name (if missing) and generate a follow-up email.
    2. AI MONITORING: If user mentions "Gemini", "Vertex AI", "Cloud Run", "pricing", or "update", calculate cost savings and analyze relevance.
    3. DECISION SYNC: If user says "decision", log it clearly. If they ask about decisions, summarize recent ones.
    
    OUTPUT FORMAT:
    [CATEGORY: Lead/AI/Decision/Meeting]
    📌 SUMMARY: [one line]
    🔧 ACTION: [specific step - optional]
    💰 SAVINGS: [if applicable]
    📝 DETAILS: [full response - just text conversation, no UI instructions]
    
    Now help the founder. Be conversational but precise.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: SYSTEM_PROMPT + "\n\nUser Message: " + prompt
  });

  const text = response.text || "";
  
  // Basic parser for the structured output
  const categoryMatch = text.match(/\[CATEGORY:\s*([^\]]+)\]/);
  const summaryMatch = text.match(/📌\s*SUMMARY:\s*(.*)/);
  const actionMatch = text.match(/🔧\s*ACTION:\s*(.*)/);
  const savingsMatch = text.match(/💰\s*SAVINGS:\s*(.*)/);
  const detailsMatch = text.match(/📝\s*DETAILS:\s*([\s\S]*)/);

  return {
    category: (categoryMatch?.[1] as AssistantCategory) || "Meeting",
    summary: summaryMatch?.[1] || "Response processed",
    actionNeeded: actionMatch?.[1] || undefined,
    costImpact: savingsMatch?.[1] && savingsMatch[1].trim() !== "N/A" ? savingsMatch[1].trim() : undefined,
    details: detailsMatch?.[1]?.trim() || text
  };
}
