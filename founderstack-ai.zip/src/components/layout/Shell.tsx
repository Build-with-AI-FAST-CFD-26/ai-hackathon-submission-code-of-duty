import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart3, 
  Users, 
  Settings, 
  LayoutDashboard, 
  Bell, 
  LogOut,
  Sparkles,
  Search,
  Plus
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

export const Sidebar = ({ 
  activeTab, 
  onTabChange, 
  onSignOut 
}: { 
  activeTab: string; 
  onTabChange: (tab: string) => void;
  onSignOut: () => void;
}) => {
  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'leads', label: 'Leads', icon: Users },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="w-64 border-r border-slate-200 h-screen flex flex-col bg-white sticky top-0">
      <div className="p-6 flex items-center gap-2 mb-4">
        <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-blue-400" />
        </div>
        <span className="font-bold text-xl tracking-tight text-slate-900">FounderStack</span>
      </div>

      <nav className="flex-1 px-4 space-y-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm cursor-pointer",
              activeTab === tab.id 
                ? "bg-slate-900 text-white shadow-lg shadow-slate-200" 
                : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
            )}
          >
            <tab.icon className={cn("w-5 h-5", activeTab === tab.id ? "text-blue-400" : "text-slate-400")} />
            {tab.label}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-100">
        <div className="p-4 bg-blue-50 rounded-2xl mb-4">
          <p className="text-[10px] font-bold text-blue-600 uppercase mb-1">Growth Plan</p>
          <p className="text-xs text-blue-800 font-medium mb-3">You're at 85% of your lead quota.</p>
          <div className="w-full h-1.5 bg-blue-200 rounded-full overflow-hidden">
            <div className="w-[85%] h-full bg-blue-600" />
          </div>
        </div>
        <button 
          onClick={onSignOut}
          className="w-full flex items-center gap-3 px-4 py-2 text-slate-500 hover:text-red-600 transition-colors text-sm font-medium cursor-pointer"
        >
          <LogOut className="w-5 h-5" />
          Sign Out
        </button>
      </div>
    </aside>
  );
};

export const Navbar = () => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showNewProject, setShowNewProject] = useState(false);
  const [activeToast, setActiveToast] = useState<string | null>(null);
  const [isGithubConnected, setIsGithubConnected] = useState(() => {
    return localStorage.getItem('founder_stack_github_connected') === 'true';
  });
  const [searchQuery, setSearchQuery] = useState('');

  const [connectedRepo, setConnectedRepo] = useState<string | null>(() => {
    return localStorage.getItem('founder_stack_github_repo');
  });

  useEffect(() => {
    const handleStorage = () => {
      setIsGithubConnected(localStorage.getItem('founder_stack_github_connected') === 'true');
      setConnectedRepo(localStorage.getItem('founder_stack_github_repo'));
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const showToast = (msg: string) => {
    setActiveToast(msg);
    setTimeout(() => setActiveToast(null), 3000);
  };

  const [notifications, setNotifications] = useState([
    { 
      id: 1, 
      title: '🔔 URGENT: Cloud Run prices increased 15%', 
      impact: '💰 Impact: +$75/month on current $500 spend',
      action: '⚡ Action: Review usage or switch to committed use.',
      time: '2m ago', 
      type: 'critical',
      read: false
    },
    { 
      id: 2, 
      title: '⚠️ Follow-up Due: Acme Corp', 
      impact: '⏳ Impact: Lead cold for 3 days',
      action: '⚡ Action: Send AI-generated follow-up.',
      time: '1h ago', 
      type: 'warning',
      read: false
    },
    { 
      id: 3, 
      title: '🚀 Gemini 3.1 Flash Released', 
      impact: '💰 Impact: -40% potential cost reduction',
      action: '⚡ Action: Update inference model.',
      time: '4h ago', 
      type: 'info',
      read: false
    },
  ]);

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    showToast("All notifications cleared");
  };

  const handleNotificationAction = (n: any) => {
    setNotifications(prev => prev.filter(item => item.id !== n.id));
    showToast(`Executed: ${n.action}`);
  };

  return (
    <header className="h-16 border-b border-slate-100 bg-white/80 backdrop-blur-md sticky top-0 z-30 px-8 flex items-center justify-between">
      {/* Toast Notification */}
      <AnimatePresence>
        {activeToast && (
          <motion.div 
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 50, opacity: 1 }}
            exit={{ y: -50, opacity: 0 }}
            className="fixed top-0 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-6 py-3 rounded-2xl shadow-2xl z-[500] font-bold text-sm border border-white/10 flex items-center gap-3"
          >
            <Sparkles className="w-4 h-4 text-blue-400" />
            {activeToast}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 max-w-xl">
        <form 
          onSubmit={(e) => {
            e.preventDefault();
            if (searchQuery) showToast(`Searching stack for: "${searchQuery}"`);
          }}
          className="relative"
        >
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search commands, leads, or integrations..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/10 transition-all font-sans"
          />
        </form>
      </div>
      <div className="flex items-center gap-4">
        <div className="relative">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              setShowNotifications(!showNotifications);
              setShowNewProject(false);
            }}
            className="p-2 text-slate-500 hover:bg-slate-50 rounded-xl relative cursor-pointer z-40"
          >
            <Bell className="w-5 h-5" />
            {notifications.some(n => !n.read) && (
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
            )}
          </button>
          
          <AnimatePresence>
            {showNotifications && (
              <>
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 z-30" 
                  onClick={() => setShowNotifications(false)} 
                />
                <motion.div 
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute right-0 mt-2 w-[340px] bg-white border border-slate-200 rounded-2xl shadow-2xl p-4 overflow-hidden origin-top-right z-40"
                >
                  <div className="flex items-center justify-between mb-4 px-2">
                    <h4 className="font-bold text-slate-900">Critical Intelligence</h4>
                    <button 
                      onClick={markAllAsRead}
                      className="text-[10px] font-bold text-blue-600 hover:underline px-2 py-0.5 rounded-full uppercase"
                    >
                      Clear All
                    </button>
                  </div>
                  <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
                    {notifications.length > 0 ? notifications.map(n => (
                      <div 
                        key={n.id} 
                        onClick={() => {
                          setShowNotifications(false);
                          handleNotificationAction(n);
                        }}
                        className={cn(
                          "p-3 hover:bg-slate-50 rounded-xl cursor-pointer transition-colors group text-left border relative",
                          n.read ? "border-transparent opacity-60" : "border-transparent hover:border-slate-100"
                        )}
                      >
                        {!n.read && (
                          <div className="absolute top-3 right-3 w-1.5 h-1.5 bg-blue-600 rounded-full" />
                        )}
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-sm font-bold text-slate-900 group-hover:text-blue-600 font-sans tracking-tight leading-tight">{n.title}</p>
                        </div>
                        <p className="text-[11px] text-slate-600 font-medium mt-1">{n.impact}</p>
                        <p className="text-[11px] text-blue-600 font-bold mt-1 bg-blue-50 px-2 py-1 rounded inline-block">{n.action}</p>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider mt-2">{n.time}</p>
                      </div>
                    )) : (
                      <div className="py-12 text-center">
                        <Bell className="w-8 h-8 text-slate-200 mx-auto mb-3" />
                        <p className="text-slate-400 font-bold text-xs uppercase tracking-widest">Inbox Clean</p>
                      </div>
                    )}
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>

        <div className="h-8 w-[1px] bg-slate-100 mx-2" />
        
        <div className="relative">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              setShowNewProject(!showNewProject);
              setShowNotifications(false);
            }}
            className="flex items-center gap-3 h-10 px-4 bg-slate-900 text-white rounded-xl cursor-pointer hover:bg-slate-800 transition-all active:scale-95 shadow-lg shadow-slate-900/10 z-40"
          >
            <Plus className="w-4 h-4 text-blue-400" />
            <span className="text-sm font-bold whitespace-nowrap">New Project</span>
          </button>

          <AnimatePresence>
            {showNewProject && (
              <>
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 z-30" 
                  onClick={() => setShowNewProject(false)} 
                />
                <motion.div 
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-2xl shadow-2xl p-2 origin-top-right z-40"
                >
                   <button 
                     onClick={() => {
                       setShowNewProject(false);
                       showToast("Lead pipeline initialized.");
                     }}
                     className="w-full text-left p-3 hover:bg-slate-50 rounded-xl flex items-center gap-3 transition-colors cursor-pointer group"
                   >
                     <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600 group-hover:bg-blue-100">
                        <Users className="w-4 h-4" />
                     </div>
                     <span className="text-sm font-bold text-slate-700">Add New Lead</span>
                   </button>
                   <button 
                     onClick={() => {
                       setShowNewProject(false);
                       showToast("Custom dashboard editor loading...");
                     }}
                     className="w-full text-left p-3 hover:bg-slate-50 rounded-xl flex items-center gap-3 transition-colors cursor-pointer group"
                   >
                      <div className="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center text-purple-600 group-hover:bg-purple-100">
                        <LayoutDashboard className="w-4 h-4" />
                      </div>
                     <span className="text-sm font-bold text-slate-700">Create Dashboard</span>
                   </button>
                   <div className="h-[1px] bg-slate-100 my-2 mx-2" />
                   <button 
                     onClick={() => {
                       setShowNewProject(false);
                       showToast("AI Audit started. Processing stack...");
                     }}
                     className="w-full text-left p-3 hover:bg-slate-50 rounded-xl flex items-center gap-3 transition-colors cursor-pointer text-blue-600 font-bold"
                   >
                     <Sparkles className="w-4 h-4" />
                     <span className="text-sm">AI Stack Audit</span>
                   </button>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>

        <button 
          onClick={() => {
            if (isGithubConnected) {
              const confirmDisconnect = window.confirm("Disconnect from GitHub?");
              if (confirmDisconnect) {
                localStorage.removeItem('founder_stack_github_connected');
                localStorage.removeItem('founder_stack_github_repo');
                setIsGithubConnected(false);
                setConnectedRepo(null);
                showToast("GitHub disconnected");
              }
            } else {
              showToast("Use Integrations panel to connect GitHub");
            }
          }}
          className="relative group cursor-pointer flex items-center gap-3"
        >
          {isGithubConnected && connectedRepo && (
            <div className="hidden lg:flex flex-col items-end mr-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Repo Sync</span>
              <span className="text-xs font-bold text-slate-900 leading-tight">{connectedRepo.split('/')[1]}</span>
            </div>
          )}
          {isGithubConnected ? (
            <div className="w-10 h-10 rounded-xl border-2 border-white shadow-xl overflow-hidden ring-2 ring-blue-500/20">
              <img 
                src="https://github.com/github.png" 
                alt="GitHub Avatar" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full" />
            </div>
          ) : (
            <div className="w-10 h-10 bg-gradient-to-tr from-blue-500 to-purple-500 rounded-xl border border-white shadow-sm ring-2 ring-slate-100 group-hover:scale-105 transition-transform" />
          )}
        </button>
      </div>
    </header>
  );
};
