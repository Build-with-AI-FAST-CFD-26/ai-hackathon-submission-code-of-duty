import { motion } from 'motion/react';
import { Search, Filter, UserSearch, Mail, Phone, Calendar, ArrowUpRight, Sparkles } from 'lucide-react';
import { LeadTable } from '../dashboard/LeadTable';

export const LeadsPage = () => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 font-sans tracking-tight">Lead Intelligence</h1>
          <p className="text-slate-500 mt-1">Real-time enrichment and automated follow-up pipeline.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 border border-slate-200 rounded-xl bg-white text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filter
          </button>
          <button className="px-4 py-2 bg-slate-900 text-white rounded-xl text-sm font-bold hover:bg-slate-800 transition-all flex items-center gap-2 shadow-lg shadow-slate-900/10">
            <UserSearch className="w-4 h-4" />
            Add Lead
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Pipeline Value', value: '$142.5k', change: '+12%', icon: <ArrowUpRight className="w-4 h-4 text-emerald-500" />, color: 'text-emerald-500' },
          { label: 'Active Leads', value: '42', change: '+5', icon: <UserSearch className="w-4 h-4 text-blue-500" />, color: 'text-blue-500' },
          { label: 'AI Follow-ups', value: '128', change: '84% success', icon: <Sparkles className="w-4 h-4 text-purple-500" />, color: 'text-purple-500' },
        ].map((stat, i) => (
          <motion.div 
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{stat.label}</span>
              {stat.icon}
            </div>
            <div className="flex items-end justify-between">
              <h3 className="text-2xl font-bold text-slate-900">{stat.value}</h3>
              <span className={`text-xs font-bold ${stat.color}`}>{stat.change}</span>
            </div>
          </motion.div>
        ))}
      </div>

      <LeadTable />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm">
          <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
            <Mail className="w-4 h-4 text-blue-500" />
            Recent AI Outreach
          </h3>
          <div className="space-y-4">
            {[1, 2, 3].map((_, i) => (
              <div key={i} className="p-4 bg-slate-50 rounded-xl border border-transparent hover:border-slate-200 transition-all cursor-pointer group">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-900">Follow-up to John Doe</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase">2h ago</span>
                </div>
                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                  "Hi John, I saw your interest in the enterprise license for Acme Corp. I'd love to jump on a quick call..."
                </p>
                <div className="mt-3 flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 text-[9px] font-bold rounded-full uppercase tracking-tighter">Opened</span>
                  <span className="text-[9px] text-slate-400 font-medium italic group-hover:text-blue-500 transition-colors">View thread →</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm">
          <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-purple-500" />
            Upcoming Interactions
          </h3>
          <div className="space-y-4">
            {[1, 2, 3].map((_, i) => (
              <div key={i} className="flex items-center gap-4 p-4 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100 cursor-pointer">
                <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center text-slate-500 font-bold text-xs uppercase">
                  {['JD', 'SM', 'RK'][i]}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-slate-900">{['John Doe', 'Sarah Miller', 'Ryan Knight'][i]}</p>
                  <p className="text-[10px] text-slate-500">Scheduled: {['Tomorrow at 2 PM', 'May 1st, 10 AM', 'May 3rd, 4 PM'][i]}</p>
                </div>
                <button className="p-2 text-slate-400 hover:text-blue-500 transition-colors">
                  <Phone className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
