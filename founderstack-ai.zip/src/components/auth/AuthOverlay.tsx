import { useState } from 'react';
import { auth } from '@/src/lib/firebase';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { motion } from 'motion/react';
import { Sparkles, ArrowRight } from 'lucide-react';

export const AuthOverlay = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    console.log("StackSense: Login attempt started...");
    setIsLoading(true);
    setError(null);
    const provider = new GoogleAuthProvider();
    try {
      console.log("StackSense: Opening Google sign-in popup...");
      const result = await signInWithPopup(auth, provider);
      console.log("StackSense: Login successful for", result.user.email);
    } catch (err: any) {
      const errorMsg = err.code === 'auth/popup-blocked' 
        ? "Popup was blocked by your browser. Please allow popups for this site."
        : (err.message || "Failed to sign in");
      
      setError(errorMsg);
      console.error("StackSense: Auth Error:", err.code, err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900 overflow-hidden">
      {/* Abstract Background */}
      <div className="absolute inset-0 overflow-hidden opacity-20">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-500 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-500 rounded-full blur-[120px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-md p-8 text-center"
      >
        <div className="mb-8 flex flex-col items-center">
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-2xl mb-4">
            <Sparkles className="w-10 h-10 text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-white tracking-tight mb-2">FounderStack</h1>
          <p className="text-slate-400">The Ultimate Founder Assistant</p>
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 rounded-3xl shadow-2xl">
          <h2 className="text-white font-semibold mb-6">Reduce your operational overhead by 40%</h2>
          
          <button
            onClick={handleLogin}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-3 bg-white text-slate-900 py-4 px-6 rounded-2xl font-bold hover:bg-slate-100 transition-all active:scale-95 disabled:opacity-50"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-slate-900/10 border-t-slate-900 rounded-full animate-spin" />
            ) : (
              <>
                <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
                Sign in with Google
              </>
            )}
          </button>

          {error && <p className="text-red-400 text-xs mt-4">{error}</p>}

          <div className="mt-8 pt-8 border-t border-white/10 space-y-4">
            <div className="flex items-center gap-4 text-left">
              <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-blue-500" />
              </div>
              <p className="text-xs text-slate-400">Real-time Lead & Follow-up tracking</p>
            </div>
            <div className="flex items-center gap-4 text-left">
              <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-purple-500" />
              </div>
              <p className="text-xs text-slate-400">AI Ecosystem Monitoring & Cost Analytics</p>
            </div>
          </div>
        </div>

        <p className="mt-8 text-slate-500 text-xs">
          By signing in, you agree to automate your growth.
        </p>
      </motion.div>
    </div>
  );
};
