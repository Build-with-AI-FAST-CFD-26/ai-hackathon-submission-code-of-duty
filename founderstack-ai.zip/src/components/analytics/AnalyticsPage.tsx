import { motion } from 'motion/react';
import { BarChart3, TrendingUp, Users, DollarSign, ArrowUpRight, ArrowDownRight, Activity, Zap } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';

const data = [
  { name: 'Mon', revenue: 4000, leads: 2400, compute: 2400 },
  { name: 'Tue', revenue: 3000, leads: 1398, compute: 2210 },
  { name: 'Wed', revenue: 2000, leads: 9800, compute: 2290 },
  { name: 'Thu', revenue: 2780, leads: 3908, compute: 2000 },
  { name: 'Fri', revenue: 1890, leads: 4800, compute: 2181 },
  { name: 'Sat', revenue: 2390, leads: 3800, compute: 2500 },
  { name: 'Sun', revenue: 3490, leads: 4300, compute: 2100 },
];

const computeStats = [
  { name: 'Gemini 1.5 Pro', usage: 65, color: '#3b82f6' },
  { name: 'Gemini 1.5 Flash', usage: 25, color: '#10b981' },
  { name: 'Cloud Run V2', usage: 10, color: '#f59e0b' },
];

export const AnalyticsPage = () => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 font-sans tracking-tight">Platform Economics</h1>
          <p className="text-slate-500 mt-1">Holistic view of revenue, compute costs, and unit economics.</p>
        </div>
        <div className="flex bg-white border border-slate-200 rounded-xl p-1 shadow-sm">
          {['24h', '7d', '30d', '1y'].map((period) => (
            <button key={period} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${period === '7d' ? 'bg-slate-900 text-white' : 'text-slate-500 hover:text-slate-900'}`}>
              {period}
            </button>
          ))}
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'MRR', value: '$24,200', change: '+14.2%', icon: <DollarSign className="w-4 h-4" />, up: true },
          { label: 'Active Users', value: '1,429', change: '+20.1%', icon: <Users className="w-4 h-4" />, up: true },
          { label: 'Compute Cost', value: '$840.12', change: '-4.3%', icon: <Zap className="w-4 h-4" />, up: false },
          { label: 'Unit Margin', value: '82%', change: '+2.4%', icon: <Activity className="w-4 h-4" />, up: true },
        ].map((stat, i) => (
          <motion.div 
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{stat.label}</span>
              <div className={`p-2 rounded-lg ${stat.up ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                {stat.icon}
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <h3 className="text-2xl font-bold text-slate-900">{stat.value}</h3>
              <span className={`text-xs font-bold flex items-center ${stat.up ? 'text-emerald-500' : 'text-red-500'}`}>
                {stat.up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                {stat.change}
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 p-6 bg-white border border-slate-200 rounded-3xl shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-500" />
              Growth Performance
            </h3>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-sm bg-blue-500" />
                <span className="text-[10px] font-bold text-slate-400 uppercase">Revenue</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-sm bg-blue-200" />
                <span className="text-[10px] font-bold text-slate-400 uppercase">Leads</span>
              </div>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 600, fill: '#94a3b8' }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 600, fill: '#94a3b8' }} 
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#colorRev)" />
                <Area type="monotone" dataKey="leads" stroke="#bfdbfe" strokeWidth={2} fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="p-6 bg-white border border-slate-200 rounded-3xl shadow-sm">
          <h3 className="font-bold text-slate-900 mb-8 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-purple-500" />
            Compute Allocation
          </h3>
          <div className="h-[200px] w-full mb-8">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={computeStats} layout="vertical" margin={{ left: -20 }}>
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 600, fill: '#64748b' }} />
                <Bar dataKey="usage" radius={[0, 4, 4, 0]} barSize={20}>
                  {computeStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-4">
            {computeStats.map((stat) => (
              <div key={stat.name} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-xs font-bold text-slate-700">{stat.name}</span>
                <span className="text-xs font-bold text-slate-900">{stat.usage}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
