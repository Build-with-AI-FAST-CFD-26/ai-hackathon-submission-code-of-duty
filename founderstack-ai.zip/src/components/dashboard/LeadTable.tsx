import { motion, AnimatePresence } from 'motion/react';
import { MoreHorizontal, User, Building, Clock, X, Mail, Phone, Calendar, ArrowRight, Sparkles } from 'lucide-react';
import { format } from 'date-fns';
import { useState } from 'react';
import { cn } from '@/src/lib/utils';

interface Lead {
  id: string;
  company: string;
  name: string;
  status: string;
  lastTouch: Date;
  value: string;
  email?: string;
  notes?: string;
}

const leads: Lead[] = [
  { id: '1', company: 'Acme Corp', name: 'John Doe', status: 'In Negotiation', lastTouch: new Date(), value: '$12,000', email: 'john@acme.com', notes: 'Interested in enterprise license for 200 users.' },
  { id: '2', company: 'Globex', name: 'Jane Smith', status: 'Initial Contact', lastTouch: new Date(), value: '$45,000', email: 'jane@globex.org', notes: 'Sourced from LinkedIn. Very high intent.' },
  { id: '3', company: 'Soylent Corp', name: 'Bob Vance', status: 'Closed Won', lastTouch: new Date(), value: '$8,500', email: 'bob@soylent.com', notes: 'Payment received. Onboarding next Monday.' },
];

export const LeadTable = ({ onTabChange }: { onTabChange?: (tab: string) => void }) => {
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [isViewAll, setIsViewAll] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedFollowup, setGeneratedFollowup] = useState<string | null>(null);

  const handleViewAll = () => {
    if (onTabChange) {
      onTabChange('leads');
    } else {
      setIsViewAll(!isViewAll);
    }
  };

  const handleGenerateFollowup = () => {
    setIsGenerating(true);
    // Simulate AI generation
    setTimeout(() => {
      setGeneratedFollowup(`Hi ${selectedLead?.name}, I'm reaching out from the FounderStack team. I saw your interest in the enterprise license for ${selectedLead?.company}. I'd love to jump on a quick call to discuss how we can tailor our solution for your specific needs. Are you free this Thursday?`);
      setIsGenerating(false);
    }, 1500);
  };

  const closeProfile = () => {
    setSelectedLead(null);
    setGeneratedFollowup(null);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <h3 className="font-bold text-slate-900">Active Leads</h3>
          {isViewAll && (
            <span className="text-[10px] bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full font-bold uppercase">All Records</span>
          )}
        </div>
        <button 
          onClick={handleViewAll}
          className="text-sm font-bold text-blue-600 hover:text-blue-700 cursor-pointer transition-colors"
        >
          {isViewAll ? 'Collapse' : 'View all'}
        </button>
      </div>
      <div className={cn("overflow-x-auto transition-all", isViewAll ? "max-h-[600px]" : "max-h-none")}>
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50">
              <th className="px-6 py-3 text-[10px] font-bold uppercase text-slate-400 tracking-wider">Company</th>
              <th className="px-6 py-3 text-[10px] font-bold uppercase text-slate-400 tracking-wider">Contact</th>
              <th className="px-6 py-3 text-[10px] font-bold uppercase text-slate-400 tracking-wider">Status</th>
              <th className="px-6 py-3 text-[10px] font-bold uppercase text-slate-400 tracking-wider">Last Touch</th>
              <th className="px-6 py-3 text-[10px] font-bold uppercase text-slate-400 tracking-wider">Value</th>
              <th className="px-6 py-3 text-[10px] font-bold uppercase text-slate-400 tracking-wider text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {leads.map((lead) => (
              <tr 
                key={lead.id} 
                onClick={() => setSelectedLead(lead)}
                className="hover:bg-slate-50/50 transition-colors cursor-pointer group"
              >
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-slate-100 flex items-center justify-center group-hover:bg-white transition-colors">
                      <Building className="w-4 h-4 text-slate-400" />
                    </div>
                    <span className="font-semibold text-slate-900 group-hover:text-blue-600 transition-colors">{lead.company}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">{lead.name}</td>
                <td className="px-6 py-4">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-100">
                    {lead.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-500">
                  {format(lead.lastTouch, 'MMM d, yyyy')}
                </td>
                <td className="px-6 py-4 font-mono text-sm text-slate-900">{lead.value}</td>
                <td className="px-6 py-4 text-right">
                  <button className="p-1 hover:bg-slate-100 rounded text-slate-400 cursor-pointer">
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <AnimatePresence>
        {selectedLead && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeProfile}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl overflow-hidden"
            >
              <button 
                onClick={closeProfile}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-50 transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600">
                  <Building className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">{selectedLead.company}</h3>
                  <div className="flex items-center gap-2 text-slate-500 text-sm">
                    <User className="w-3 h-3" />
                    <span>{selectedLead.name}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="p-4 bg-slate-50 rounded-2xl">
                  <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Status</p>
                  <p className="font-bold text-blue-600">{selectedLead.status}</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl">
                  <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Value</p>
                  <p className="font-bold text-slate-900">{selectedLead.value}</p>
                </div>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3 text-slate-600">
                  <Mail className="w-4 h-4" />
                  <span className="text-sm">{selectedLead.email}</span>
                </div>
                <div className="flex items-center gap-3 text-slate-600">
                  <Phone className="w-4 h-4" />
                  <span className="text-sm">+1 (555) 000-0000</span>
                </div>
                <div className="pt-4 border-t border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-2">Notes</p>
                  <p className="text-sm text-slate-700 leading-relaxed italic">"{selectedLead.notes}"</p>
                </div>
              </div>

              {generatedFollowup ? (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="bg-blue-50 border border-blue-100 rounded-2xl p-4 mb-6 overflow-hidden"
                >
                  <div className="flex items-center gap-2 text-blue-600 mb-2">
                    <Sparkles className="w-3 h-3" />
                    <span className="text-[10px] font-bold uppercase tracking-wider">AI Draft</span>
                  </div>
                  <p className="text-xs text-slate-700 italic leading-relaxed">
                    {generatedFollowup}
                  </p>
                </motion.div>
              ) : null}

              <div className="space-y-3">
                <button 
                  onClick={handleGenerateFollowup}
                  disabled={isGenerating}
                  className={cn(
                    "w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-slate-900/20",
                    isGenerating && "opacity-70 cursor-wait"
                  )}
                >
                  {isGenerating ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-blue-400" />
                      {generatedFollowup ? 'Regenerate Draft' : 'Generate AI Follow-up'}
                    </>
                  )}
                </button>
                <button 
                  onClick={closeProfile}
                  className="w-full py-4 text-slate-500 font-bold hover:text-slate-700 transition-colors cursor-pointer"
                >
                  Close Profile
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
