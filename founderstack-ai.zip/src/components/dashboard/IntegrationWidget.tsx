import { motion, AnimatePresence } from 'motion/react';
import { Slack, Github, Calendar as GoogleCalendar, CheckCircle2, XCircle, ExternalLink, X } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/src/lib/utils';

interface IntegrationWidgetProps {
  name: string;
  type: 'Slack' | 'Jira' | 'GoogleWorkspace' | 'GitHub';
  status: 'connected' | 'disconnected' | 'error';
  lastSync?: string;
  onClick?: () => void;
}

const icons = {
  Slack: <Slack className="w-6 h-6 text-[#4A154B]" />,
  GitHub: <Github className="w-6 h-6 text-slate-900" />,
  GoogleWorkspace: <GoogleCalendar className="w-6 h-6 text-blue-500" />,
  Jira: <div className="w-6 h-6 bg-blue-600 rounded-sm flex items-center justify-center text-white font-bold text-[10px]">J</div>,
};

export const IntegrationWidget = ({ name, type, status: initialStatus, lastSync }: IntegrationWidgetProps) => {
  const [showModal, setShowModal] = useState(false);
  const [status, setStatus] = useState(() => {
    if (type === 'GitHub') {
      const saved = localStorage.getItem('founder_stack_github_connected');
      return saved === 'true' ? 'connected' : initialStatus;
    }
    return initialStatus;
  });
  const [isConnecting, setIsConnecting] = useState(false);
  const [selectedRepo, setSelectedRepo] = useState<string | null>(() => {
    if (type === 'GitHub') {
      return localStorage.getItem('founder_stack_github_repo');
    }
    return null;
  });
  const [isCreatingRepo, setIsCreatingRepo] = useState(false);
  const [newRepoName, setNewRepoName] = useState('');

  const repos = [
    'founder-stack-ai/core',
    'founder-stack-ai/dashboard',
    'founder-stack-ai/docs'
  ];

  const handleCreateRepo = () => {
    if (!newRepoName) return;
    setIsCreatingRepo(true);
    setTimeout(() => {
      const fullRepoName = `founder-stack-ai/${newRepoName.toLowerCase().replace(/\s+/g, '-')}`;
      setSelectedRepo(fullRepoName);
      localStorage.setItem('founder_stack_github_repo', fullRepoName);
      localStorage.setItem('founder_stack_github_connected', 'true');
      setIsCreatingRepo(false);
      window.dispatchEvent(new Event('storage')); // Notify other components
      setTimeout(() => setShowModal(false), 800);
    }, 2000);
  };

  const handleConnect = () => {
    if (status === 'connected' && type !== 'GitHub') {
      setShowModal(false);
      return;
    }

    if (type === 'GitHub' && status === 'connected' && !selectedRepo) {
      return;
    }

    setIsConnecting(true);
    setTimeout(() => {
      setIsConnecting(false);
      setStatus('connected');
      if (type === 'GitHub') {
        localStorage.setItem('founder_stack_github_connected', 'true');
        window.dispatchEvent(new Event('storage'));
      }
      if (type !== 'GitHub') {
        setTimeout(() => setShowModal(false), 800);
      }
    }, 2000);
  };

  const handleSelectRepo = (repo: string) => {
    setSelectedRepo(repo);
    localStorage.setItem('founder_stack_github_repo', repo);
    localStorage.setItem('founder_stack_github_connected', 'true');
    window.dispatchEvent(new Event('storage'));
    setTimeout(() => setShowModal(false), 500);
  };

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => setShowModal(true)}
        className="w-full p-4 flex items-center justify-between bg-white border border-slate-200 rounded-xl transition-all hover:bg-slate-50 text-left cursor-pointer group"
      >
        <div className="flex items-center gap-4">
          <div className="p-2 bg-slate-50 rounded-lg group-hover:bg-white transition-colors">
            {icons[type]}
          </div>
          <div>
            <h4 className="font-semibold text-slate-900">
              {type === 'GitHub' && selectedRepo ? `GitHub: ${selectedRepo.split('/')[1]}` : name}
            </h4>
            <p className="text-xs text-slate-500">
              {status === 'connected' ? `Last sync: ${lastSync || 'Just now'}` : 'Click to connect'}
            </p>
          </div>
        </div>
        <div>
          {status === 'connected' ? (
            <CheckCircle2 className="w-5 h-5 text-green-500" />
          ) : status === 'error' ? (
            <XCircle className="w-5 h-5 text-red-500" />
          ) : (
            <div className="w-5 h-5 border-2 border-slate-200 rounded-full" />
          )}
        </div>
      </motion.button>

      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !isConnecting && setShowModal(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white rounded-3xl p-8 max-w-sm w-full shadow-2xl overflow-hidden"
            >
              {!isConnecting && (
                <button 
                  onClick={() => setShowModal(false)}
                  className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-50 transition-colors"
                  aria-label="Close"
                >
                  <X className="w-4 h-4" />
                </button>
              )}

              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mb-6 shadow-sm border border-slate-100">
                  {icons[type]}
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">
                  {isConnecting ? 'Linking Account...' : (status === 'connected' ? (type === 'GitHub' ? (selectedRepo ? 'Repo Connected' : 'Select Repository') : `${name} Connected!`) : `Connect ${name}`)}
                </h3>
                <p className="text-slate-500 text-sm mb-8">
                  {isConnecting 
                    ? "Establishing a secure OAuth tunnel to your workspace..."
                    : (status === 'connected' 
                      ? (type === 'GitHub' && !selectedRepo 
                        ? 'Account linked! Choose an existing repository to monitor or initialize a new one for this stack.'
                        : `FounderStack is currently synced with your ${name}. You are receiving real-time insights for stack optimizations.`)
                      : `Link your ${name} account to let FounderStack AI monitor deployments, track commits, and automate lead follow-ups.`)}
                </p>

                <div className="w-full space-y-4">
                  {status === 'connected' && type === 'GitHub' && !isConnecting && (
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1 block text-left">Choose Existing Repository</label>
                        {repos.map(repo => (
                          <button
                            key={repo}
                            onClick={() => handleSelectRepo(repo)}
                            className={cn(
                              "w-full p-3 text-sm font-medium border rounded-xl text-left transition-all hover:bg-blue-50 hover:border-blue-200 cursor-pointer flex items-center justify-between group",
                              selectedRepo === repo ? "bg-blue-50 border-blue-200" : "bg-white border-slate-200"
                            )}
                          >
                            <span>{repo}</span>
                            <div className="w-4 h-4 rounded-full border border-slate-200 flex items-center justify-center group-hover:border-blue-300">
                              {selectedRepo === repo && <div className="w-2 h-2 bg-blue-600 rounded-full" />}
                            </div>
                          </button>
                        ))}
                      </div>

                      <div className="relative">
                        <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100" /></div>
                        <div className="relative flex justify-center text-[10px]"><span className="px-2 bg-white text-slate-400 font-bold uppercase italic">or</span></div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1 block text-left">Create New Repository</label>
                        <div className="flex gap-2">
                          <input 
                            type="text" 
                            placeholder="my-new-repo"
                            value={newRepoName}
                            onChange={(e) => setNewRepoName(e.target.value)}
                            className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/10 transition-all font-sans"
                            disabled={isCreatingRepo}
                          />
                          <button 
                            onClick={handleCreateRepo}
                            disabled={!newRepoName || isCreatingRepo}
                            className="px-4 py-3 bg-slate-900 text-white text-sm font-bold rounded-xl hover:bg-slate-800 disabled:opacity-50 transition-all whitespace-nowrap cursor-pointer shadow-lg shadow-slate-900/10"
                          >
                            {isCreatingRepo ? "Creating..." : "Create & Sync"}
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {(status !== 'connected' || (type === 'GitHub' && !selectedRepo)) && !isCreatingRepo && (
                    <button 
                      onClick={handleConnect}
                      disabled={isConnecting}
                      className={cn(
                        "w-full py-3.5 text-white rounded-2xl font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-blue-500/20",
                        isConnecting ? "bg-blue-400" : "bg-blue-600 hover:bg-blue-700 active:scale-[0.98]"
                      )}
                    >
                      {isConnecting ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          <span>{status === 'connected' ? 'Update Selection' : 'Authenticate Integration'}</span>
                          <ExternalLink className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  )}

                  {status === 'connected' && (type !== 'GitHub' || selectedRepo) && !isConnecting && (
                    <button 
                      onClick={() => setShowModal(false)}
                      className="w-full py-3.5 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
                    >
                      Open Dashboard
                    </button>
                  )}

                  {!isConnecting && (
                    <button 
                      onClick={() => setShowModal(false)}
                      className="w-full py-3.5 text-slate-500 font-bold hover:text-slate-700 transition-colors cursor-pointer"
                    >
                      {status === 'connected' ? 'Close' : 'Cancel'}
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
