import { motion } from 'motion/react';
import { History, UserPlus, FileEdit, Zap } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export const AuditLog = () => {
  const logs = [
    { 
      id: 1, 
      action: 'Lead Created', 
      detail: 'Acme Corp added to pipeline', 
      user: 'Paul', 
      time: '10 mins ago',
      icon: <UserPlus className="w-3.5 h-3.5" />,
      color: 'bg-blue-500'
    },
    { 
      id: 2, 
      action: 'Status Change', 
      detail: 'Stark Industries -> In Negotiation', 
      user: 'Paul', 
      time: '45 mins ago',
      icon: <FileEdit className="w-3.5 h-3.5" />,
      color: 'bg-purple-500'
    },
    { 
      id: 3, 
      action: 'Decision Logged', 
      detail: 'Pivoted lead outreach to LinkedIn', 
      user: 'Sam', 
      time: '2 hours ago',
      icon: <Zap className="w-3.5 h-3.5" />,
      color: 'bg-orange-500'
    },
  ];

  return (
    <section className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-bold text-slate-900 flex items-center gap-2">
          <History className="w-4 h-4 text-slate-400" />
          Audit Log
        </h3>
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">History</span>
      </div>
      <div className="space-y-4">
        {logs.map((log, i) => (
          <motion.div 
            key={log.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="flex gap-4 relative"
          >
            {i !== logs.length - 1 && (
              <div className="absolute left-[13px] top-8 bottom-[-16px] w-[2px] bg-slate-100" />
            )}
            <div className={cn(
              "w-7 h-7 rounded-lg flex items-center justify-center text-white shrink-0 shadow-sm",
              log.color
            )}>
              {log.icon}
            </div>
            <div className="flex-1 pb-4">
              <div className="flex justify-between items-start">
                <p className="text-sm font-bold text-slate-900">{log.action}</p>
                <span className="text-[10px] text-slate-400 font-bold uppercase">{log.time}</span>
              </div>
              <p className="text-xs text-slate-500 mt-1">{log.detail}</p>
              <div className="mt-2 flex items-center gap-1.5">
                <div className="w-4 h-4 bg-slate-100 rounded-full flex items-center justify-center text-[8px] font-bold text-slate-500">
                  {log.user[0]}
                </div>
                <span className="text-[10px] text-slate-400 font-medium">Logged by {log.user}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};
