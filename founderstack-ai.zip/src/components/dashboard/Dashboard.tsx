import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TrendingUp, 
  Users, 
  MessageSquare, 
  Zap,
  ArrowUpRight,
  Plus,
  Cpu,
  LineChart
} from 'lucide-react';
import { StatCard } from './StatCard';
import { IntegrationWidget } from './IntegrationWidget';
import { LeadTable } from './LeadTable';
import { RevenueChart } from './RevenueChart';
import { AIUsageWidget } from './AIUsageWidget';
import { DecisionLog } from './DecisionLog';
import { DeadlinesWidget } from './DeadlinesWidget';
import { AuditLog } from './AuditLog';

export const Dashboard = ({ onTabChange }: { onTabChange: (tab: string) => void }) => {
  const [persona, setPersona] = useState<'Paul' | 'Sam'>('Paul');

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-3">
            {persona === 'Sam' ? <Cpu className="w-8 h-8 text-blue-600" /> : <LineChart className="w-8 h-8 text-blue-600" />}
            Founder Console
          </h1>
          <p className="text-slate-500 mt-1">
            Hello, <span className="text-blue-600 font-bold">{persona}</span>. FounderStack AI has {persona === 'Paul' ? '2 new insights' : '4 system optimizations'} for you.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative group">
            <select 
              value={persona}
              onChange={(e) => setPersona(e.target.value as any)}
              className="appearance-none pl-4 pr-10 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/10 cursor-pointer hover:border-slate-300 transition-all shadow-sm"
            >
              <option value="Paul">Paul (Business)</option>
              <option value="Sam">Sam (Technical)</option>
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
               <ArrowUpRight className="w-4 h-4 rotate-90" />
            </div>
          </div>
        </div>
      </header>

      {/* Stats Grid */}
      <motion.div 
        layout
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
      >
        <StatCard 
          title={persona === 'Sam' ? "API Efficiency" : "Total ARPU"} 
          value={persona === 'Sam' ? "94.2%" : "$124,592"} 
          change="+12.5%" 
          trend="up"
          icon={persona === 'Sam' ? <Cpu className="w-5 h-5" /> : <TrendingUp className="w-5 h-5" />}
          color="blue"
        />
        <StatCard 
          title={persona === 'Sam' ? "System Uptime" : "Leads Needed"} 
          value={persona === 'Sam' ? "99.99%" : "14"} 
          change={persona === 'Sam' ? "Stable" : "-4"} 
          trend={persona === 'Sam' ? "up" : "down"}
          icon={persona === 'Sam' ? <Zap className="w-5 h-5" /> : <Users className="w-5 h-5" />}
          color="green"
        />
        <StatCard 
          title={persona === 'Sam' ? "Compute Cost" : "Acquisition Cost"} 
          value={persona === 'Sam' ? "$1,240" : "$42.10"} 
          change={persona === 'Sam' ? "-$480" : "+$2.50"} 
          trend={persona === 'Sam' ? "down" : "up"}
          icon={<Zap className="w-5 h-5" />}
          color="orange"
        />
        <StatCard 
          title="Sync Health" 
          value="98.2%" 
          icon={<MessageSquare className="w-5 h-5" />}
          color="purple"
        />
      </motion.div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
        {/* Main Content Areas */}
        <div className="xl:col-span-8 space-y-8">
          <AnimatePresence mode="popLayout">
            {persona === 'Paul' ? (
              <motion.div
                key="paul-view"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <section className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm">
                  <div className="flex items-center justify-between mb-8">
                    <div>
                      <h3 className="font-bold text-slate-900 text-lg">Revenue Overview</h3>
                      <p className="text-xs text-slate-500">Weekly growth tracking</p>
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-slate-400" />
                  </div>
                  <RevenueChart />
                </section>
                <LeadTable onTabChange={onTabChange} />
              </motion.div>
            ) : (
              <motion.div
                key="sam-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="space-y-8"
              >
                <AIUsageWidget />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <DecisionLog />
                  <DeadlinesWidget />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Sidebar Widgets */}
        <div className="xl:col-span-4 space-y-8">
          {persona === 'Paul' && (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-1 gap-8">
              <AuditLog />
              <DecisionLog />
              <DeadlinesWidget />
            </div>
          )}
          
          {persona === 'Sam' && (
            <div className="space-y-8">
              <AuditLog />
              <section className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm">
                <h3 className="font-bold text-slate-900 text-lg mb-4">Infrastructure Status</h3>
              <div className="space-y-4">
                <div className="p-4 bg-slate-50 rounded-xl flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-600">Cloud Run</span>
                  <span className="text-xs font-bold text-green-600 bg-green-100 px-2 py-0.5 rounded-full">HEALTHY</span>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-600">PostgreSQL</span>
                  <span className="text-xs font-bold text-green-600 bg-green-100 px-2 py-0.5 rounded-full">92% LOAD</span>
                </div>
              </div>
            </section>
          </div>
        )}

          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900">Integrations</h3>
              <Plus className="w-4 h-4 text-slate-400 cursor-pointer" />
            </div>
            <IntegrationWidget name="Slack" type="Slack" status="connected" lastSync="2 mins ago" />
            <IntegrationWidget name="Jira" type="Jira" status="connected" lastSync="1 hour ago" />
            <IntegrationWidget name="Google Calendar" type="GoogleWorkspace" status="disconnected" />
            <IntegrationWidget name="GitHub" type="GitHub" status="error" />
          </section>
        </div>
      </div>
    </div>
  );
};

