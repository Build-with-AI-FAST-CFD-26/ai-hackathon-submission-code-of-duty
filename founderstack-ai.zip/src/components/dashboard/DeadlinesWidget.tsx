import { motion, AnimatePresence } from 'motion/react';
import { Calendar, CheckCircle2, X, Clock, AlertCircle } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { useState } from 'react';

export const DeadlinesWidget = () => {
  const [selectedItem, setSelectedItem] = useState<any>(null);

  const items = [
    { 
      title: 'YC S26 Application', 
      date: 'Fri, May 15', 
      progress: 40, 
      status: 'Warning',
      description: 'The Y Combinator Summer 2026 application deadline is approaching. We have completed the team and product sections, but the "Why us?" and MRR growth projections are still in draft.',
      tasks: ['Draft MRR figures', 'Record demo video', 'Review with Sam'],
      priority: 'High'
    },
    { 
      title: 'Seed Round Pitch Deck', 
      date: 'Mon, May 18', 
      progress: 85, 
      status: 'Good',
      description: 'Final touches on the seed round deck. Traction slides look strong after last week\'s customer onboarding.',
      tasks: ['Update latest cohort chart', 'Final proofread', 'Export to PDF'],
      priority: 'Medium'
    },
  ];

  return (
    <>
      <div className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-bold text-slate-900">Founder Deadlines</h3>
          <Calendar className="w-4 h-4 text-slate-400" />
        </div>
        <div className="space-y-6">
          {items.map((item, i) => (
            <div 
              key={i} 
              onClick={() => setSelectedItem(item)}
              className="cursor-pointer group"
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">{item.title}</p>
                  <p className="text-xs text-slate-500">{item.date}</p>
                </div>
                {item.progress === 100 && <CheckCircle2 className="w-4 h-4 text-green-500" />}
              </div>
              <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${item.progress}%` }}
                  className={cn(
                    "h-full rounded-full transition-all duration-1000",
                    item.status === 'Warning' ? "bg-orange-500" : "bg-blue-600"
                  )}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {selectedItem && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedItem(null)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl overflow-hidden"
            >
              <button 
                onClick={() => setSelectedItem(null)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-50 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="mb-6">
                <div className={cn(
                  "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase mb-4",
                  selectedItem.status === 'Warning' ? "bg-orange-100 text-orange-600" : "bg-blue-100 text-blue-600"
                )}>
                  {selectedItem.status === 'Warning' ? <AlertCircle className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                  {selectedItem.priority} Priority
                </div>
                <h3 className="text-2xl font-bold text-slate-900">{selectedItem.title}</h3>
                <p className="text-slate-500 font-medium">{selectedItem.date}</p>
              </div>

              <div className="space-y-6 mb-8">
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase mb-2">Description</p>
                  <p className="text-sm text-slate-700 leading-relaxed">{selectedItem.description}</p>
                </div>

                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase mb-3">Pending Tasks</p>
                  <div className="space-y-2">
                    {selectedItem.tasks.map((task: string, i: number) => (
                      <div key={i} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                        <div className="w-4 h-4 border-2 border-slate-300 rounded cursor-pointer hover:border-blue-500 transition-colors" />
                        <span className="text-sm text-slate-800 font-medium">{task}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setSelectedItem(null)}
                className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-transform active:scale-[0.98] cursor-pointer"
              >
                Go to Project
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
