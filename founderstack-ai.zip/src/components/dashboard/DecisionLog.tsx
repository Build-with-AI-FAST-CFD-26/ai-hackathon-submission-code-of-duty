import { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, AlertCircle, User } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export const DecisionLog = () => {
  const [decisions, setDecisions] = useState([
    { id: 1, text: "Switched default model to Gemini 1.5 Flash", owner: "Sam", type: "Tech", status: "Synced" },
    { id: 2, text: "Committed to Net-30 for Acme Corp", owner: "Paul", type: "Business", status: "Pending Sync" },
  ]);

  const handleAddDecision = () => {
    const newDecision = {
      id: decisions.length + 1,
      text: "New decision recorded via AI Audit",
      owner: "Founder",
      type: "Audit",
      status: "Synced"
    };
    setDecisions([newDecision, ...decisions]);
  };

  const handleSync = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    setDecisions(prev => prev.map(d => 
      d.id === id ? { ...d, status: 'Synced' } : d
    ));
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex items-center justify-between">
        <h3 className="font-bold text-slate-900">Decision Sync</h3>
        <button 
          onClick={handleAddDecision}
          className="text-[10px] font-bold text-blue-600 hover:bg-blue-50 px-2 py-1 rounded-lg transition-colors cursor-pointer"
        >
          + Log New
        </button>
      </div>
      <div className="p-4 space-y-3">
        {decisions.map((d) => (
          <motion.div 
            key={d.id} 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3 p-3 rounded-xl border border-slate-100 hover:border-blue-100 transition-all cursor-pointer hover:bg-slate-50 group"
          >
            <div className={cn(
              "p-2 rounded-lg shrink-0",
              d.status === 'Synced' ? "bg-green-50 text-green-600" : "bg-orange-50 text-orange-600"
            )}>
              {d.status === 'Synced' ? <ShieldCheck className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-900 truncate leading-tight">{d.text}</p>
              <div className="flex items-center gap-3 mt-1">
                <span className="flex items-center gap-1 text-[10px] font-bold text-slate-400 uppercase">
                  <User className="w-3 h-3" /> {d.owner}
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 uppercase">
                  {d.type}
                </span>
              </div>
            </div>
            {d.status !== 'Synced' && (
              <button 
                onClick={(e) => handleSync(e, d.id)}
                className="opacity-0 group-hover:opacity-100 px-3 py-1 bg-blue-600 text-white text-[10px] font-bold rounded-lg shadow-lg shadow-blue-500/20 transition-all hover:bg-blue-700 cursor-pointer"
              >
                Sync Now
              </button>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};
