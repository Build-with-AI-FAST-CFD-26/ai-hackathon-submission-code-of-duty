import { motion, AnimatePresence } from 'motion/react';
import { Zap, ArrowRight, TrendingDown, X, Info, Coins, Cpu } from 'lucide-react';
import { useState } from 'react';

export const AIUsageWidget = () => {
  const [selectedUpdate, setSelectedUpdate] = useState<any>(null);

  const updates = [
    { 
      title: 'Gemini 3.1 Flash', 
      impact: '40% Cost Reduction', 
      savings: '$480/mo', 
      priority: 'URGENT',
      details: 'Google just released Gemini 3.1 Flash. By switching our main inference pipeline from Pro to Flash, we can reduce costs by 40% without significant loss in reasoning quality for lead scoring.',
      stats: [
        { label: 'Latency', value: '-120ms' },
        { label: 'Context', value: '1M Tokens' }
      ]
    },
    { 
      title: 'Cloud Run V2', 
      impact: '2x Concurrency', 
      savings: 'Performance Boost', 
      priority: 'THIS-WEEK',
      details: 'Upgrading to Cloud Run V2 enables persistent disk and better concurrency management. This will solve the cold start spikes we\'ve been seeing in the Singapore region.',
      stats: [
        { label: 'Cold Start', value: '-60%' },
        { label: 'Max Con.', value: '250' }
      ]
    },
  ];

  return (
    <>
      <section className="p-6 bg-slate-900 rounded-2xl text-white shadow-xl">
        <h3 className="font-bold mb-4 flex items-center gap-2 text-blue-400">
           <Zap className="w-4 h-4" />
           AI Ecosystem Monitor
        </h3>
        <div className="space-y-4">
          {updates.map((update, i) => (
            <div 
              key={i} 
              onClick={() => setSelectedUpdate(update)}
              className="p-3 bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 transition-colors cursor-pointer group"
            >
              <div className="flex justify-between items-start mb-2">
                <p className="text-[10px] font-bold text-blue-300 uppercase tracking-wider">{update.priority}</p>
                <TrendingDown className="w-4 h-4 text-green-400" />
              </div>
              <p className="text-sm font-bold group-hover:text-blue-300 transition-colors">{update.title}</p>
              <p className="text-xs text-slate-400 mt-1">{update.impact}</p>
              <div className="mt-3 flex items-center justify-between text-[11px] font-bold text-green-400 bg-green-400/10 px-2 py-1 rounded">
                <span>Savings: {update.savings}</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      <AnimatePresence>
        {selectedUpdate && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedUpdate(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" 
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-slate-900 text-white rounded-3xl p-8 max-w-md w-full shadow-2xl border border-white/10"
            >
              <button 
                onClick={() => setSelectedUpdate(null)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full hover:bg-white/5 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="mb-6">
                <div className="w-12 h-12 bg-blue-500/20 rounded-2xl flex items-center justify-center text-blue-400 mb-4">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold tracking-tight">{selectedUpdate.title}</h3>
                <p className="text-blue-400 font-bold uppercase text-[10px] tracking-widest mt-1">{selectedUpdate.priority} ACTION</p>
              </div>

              <div className="space-y-6 mb-8">
                <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                  <div className="flex items-center gap-2 mb-2 text-slate-400">
                    <Info className="w-3.5 h-3.5" />
                    <span className="text-[10px] font-bold uppercase tracking-widest">Intelligence Report</span>
                  </div>
                  <p className="text-sm text-slate-300 leading-relaxed italic">
                    "{selectedUpdate.details}"
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {selectedUpdate.stats.map((stat: any, i: number) => (
                    <div key={i} className="p-4 bg-white/5 rounded-2xl border border-white/5 flex flex-col items-center text-center">
                      <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">{stat.label}</p>
                      <p className="text-lg font-bold text-white">{stat.value}</p>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between p-4 bg-green-500/10 rounded-2xl border border-green-500/20">
                  <div className="flex items-center gap-3">
                    <Coins className="w-5 h-5 text-green-400" />
                    <div>
                      <p className="text-[10px] font-bold text-green-500 uppercase">Estimated Savings</p>
                      <p className="text-xl font-bold text-white">{selectedUpdate.savings}</p>
                    </div>
                  </div>
                  <TrendingDown className="w-6 h-6 text-green-400" />
                </div>
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => setSelectedUpdate(null)}
                  className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-500 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-blue-600/20"
                >
                  <Cpu className="w-4 h-4" />
                  Apply Optimization
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
