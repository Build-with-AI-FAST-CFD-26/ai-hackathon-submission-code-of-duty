import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Send, X, Bot, User, Clock, CheckCircle, AlertTriangle, Info, TrendingUp, Calendar, Zap } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { askAssistant, AssistantResponse } from '@/src/services/gemini';

export const StackSenseAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant', content: string | AssistantResponse }[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    try {
      const response = await askAssistant(userMsg);
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'assistant', content: "Sorry, I'm having trouble processing that right now." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="mb-4 w-[400px] max-h-[600px] bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-blue-400" />
                <span className="font-bold">FounderStack AI</span>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-1 hover:bg-slate-800 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[300px]">
              {messages.length === 0 && (
                <div className="text-center py-10 text-slate-400">
                  <Bot className="w-12 h-12 mx-auto mb-2 opacity-20" />
                  <p>How can I help you today, Founder?</p>
                </div>
              )}
              {messages.map((msg, i) => (
                <div key={i} className={cn(
                  "flex gap-3",
                  msg.role === 'user' ? "flex-row-reverse" : ""
                )}>
                  <div className={cn(
                    "p-2 rounded-lg shrink-0 h-fit",
                    msg.role === 'user' ? "bg-blue-500 text-white" : "bg-slate-100 text-slate-600"
                  )}>
                    {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                  </div>
                  <div className={cn(
                    "max-w-[80%] rounded-2xl px-4 py-2 text-sm",
                    msg.role === 'user' ? "bg-blue-500 text-white" : "bg-slate-50 border border-slate-200"
                  )}>
                    {typeof msg.content === 'string' ? (
                      msg.content
                    ) : (
                      <AssistantCard response={msg.content} />
                    )}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex gap-3 animate-pulse">
                  <div className="p-2 bg-slate-100 rounded-lg h-fit">
                    <Bot className="w-4 h-4 text-slate-400" />
                  </div>
                  <div className="h-10 w-24 bg-slate-100 rounded-2xl" />
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-4 border-t border-slate-100 bg-slate-50/50">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Talk to FounderStack..."
                  className="flex-1 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                />
                <button
                  onClick={handleSend}
                  className="p-2 bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-colors"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="relative w-16 h-16 bg-slate-900 text-white rounded-full shadow-xl flex items-center justify-center hover:bg-slate-800 transition-colors border-2 border-white/10 cursor-pointer group"
      >
        <div className="absolute inset-0 rounded-full bg-slate-900 animate-ping opacity-20 group-hover:hidden" />
        {isOpen ? <X className="w-8 h-8" /> : <Sparkles className="w-8 h-8 text-blue-400" />}
        
        {!isOpen && (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 2 }}
            className="absolute right-20 bg-white text-slate-900 px-4 py-2 rounded-xl shadow-2xl border border-slate-200 whitespace-nowrap pointer-events-none"
          >
            <p className="text-xs font-bold font-sans tracking-tight">Try: "Help me follow up with Acme Corp"</p>
            <div className="absolute top-1/2 -right-2 -translate-y-1/2 w-4 h-4 bg-white border-r border-t border-slate-200 rotate-45" />
          </motion.div>
        )}
      </motion.button>
    </div>
  );
};

const AssistantCard = ({ response }: { response: AssistantResponse }) => {
  const icons = {
    Lead: <TrendingUp className="w-4 h-4 text-green-500" />,
    AI: <Zap className="w-4 h-4 text-purple-500" />,
    Decision: <CheckCircle className="w-4 h-4 text-blue-500" />,
    Meeting: <Info className="w-4 h-4 text-slate-500" />
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between pb-2 border-bottom border-slate-200">
        <div className="flex items-center gap-2 font-bold text-slate-900">
          {icons[response.category as keyof typeof icons]}
          <span>{response.category}</span>
        </div>
      </div>
      <p className="font-semibold text-slate-900">{response.summary}</p>
      {response.actionNeeded && (
        <div className="p-2 bg-slate-900/5 rounded-lg border border-slate-900/10">
          <p className="text-[10px] uppercase font-bold text-slate-400 mb-1">Action</p>
          <p className="font-medium text-slate-800">{response.actionNeeded}</p>
        </div>
      )}
      {response.costImpact && (
        <div className="flex items-center gap-2 text-xs font-bold text-green-600">
          <span>💰 {response.costImpact}</span>
        </div>
      )}
      <div className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap">
        {response.details}
      </div>
    </div>
  );
};
