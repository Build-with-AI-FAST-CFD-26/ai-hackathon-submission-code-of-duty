import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

async function testConnection() {
  console.log("FounderStack: Testing Firebase connectivity...");
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("FounderStack: Firebase connection verified.");
  } catch (error: any) {
    console.warn("FounderStack: Connectivity check returned:", error.message);
    if (error.message.includes('the client is offline')) {
      console.error("FounderStack: Client appears offline. Firebase requires internet access.");
    }
  }
}

if (typeof window !== 'undefined') {
  testConnection();
}
