import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false,
    },
    resources: {
      en: {
        translation: {
          dashboard: 'Dashboard',
          leads: 'Leads',
          integrations: 'Integrations',
          analytics: 'Analytics',
          settings: 'Settings',
          assistant: 'StackSense Assistant',
          connected: 'Connected',
          disconnected: 'Disconnected',
        },
      },
      es: {
        translation: {
          dashboard: 'Tablero',
          leads: 'Prospectos',
          integrations: 'Integraciones',
          analytics: 'Analítica',
          settings: 'Configuración',
          assistant: 'Asistente StackSense',
          connected: 'Conectado',
          disconnected: 'Desconectado',
        },
      },
    },
  });

export default i18n;
